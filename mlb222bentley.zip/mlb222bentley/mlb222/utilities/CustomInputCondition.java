package mlb222.utilities;

public interface CustomInputCondition {
  public boolean isValidInput(String input);
}